#include <iostream>
using namespace std;

int main() {
    // 3 3 -> 8
    // 2 3 -> 5
    int n, m;
    cin >> n >> m;
    cout << n * m - 1 << endl;
    return 0;
}